

function [norme] = calculNorme (vitesse)

norme = sqrt(vitesse(1)^2 + vitesse(2)^2 + vitesse(3)^2);

endfunction
