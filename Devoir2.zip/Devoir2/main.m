#Permettre la compilation de devoir1
clear all;
clc;


ballonRayon = 0.11; # en mètre
ballonMasse = 0.45; # en kg


#condition1 = Devoir2([0.2;89.8;0.11], [5.3;-21;16.5], [0;0;6.3]);
#condition2 = Devoir2([0.2;89.8;0.11], [5.3;-21;16.5], [0;-5;-6.3]);
#condition3 = Devoir2([0.2;89.8;0.11], [5.3;-21;16.5], [0;0;-6.5]);
#condition4 = Devoir2([0.2;89.8;0.11], [5.3;-21;18.3], [0;0;-6.3]);
condition5 = Devoir2([119.8;89.8;0.11], [-5.3;-21;16.5], [0;-3;6.3]);

%condition1;
%condition2;
%condition3;
%condition4;
%disp("result: ");
%disp(condition5);


